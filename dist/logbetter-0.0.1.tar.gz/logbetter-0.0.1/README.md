# logbetter

A simple, colorful logging utility for Python.

## Example
```python
from logbetter import logbetter

logbetter.info("This is an info message.")
logbetter.success("Operation completed!")
```
