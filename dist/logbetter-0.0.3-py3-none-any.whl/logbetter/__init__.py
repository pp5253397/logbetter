from .logbetter import log, LogBetter

__all__ = ["log", "LogBetter"]
__version__ = "0.0.3"
